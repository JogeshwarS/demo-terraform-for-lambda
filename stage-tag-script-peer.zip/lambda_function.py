from tag_ec2 import ec2_tag
from tag_elb import elb_tag
from tag_autoscaling import autoscaling_tag
from tag_eks import eks_tag
from tag_rds import rds_tag
from tag_s3 import s3_tag
from tag_codepipeline import codepipeline_tag
from tag_codebuild import codebuild_tag
from tag_cloudtrail import cloudtrail_tag
from tag_cloudfront import cloudfront_tag
from tag_secrets import secrets_tag
from tag_kms import kms_tag
from tag_lambda import lambda_function_tag
from tag_apigateway import apigateway_tag
from tag_sns import sns_tag
from tag_guardduty import guardduty_tag
from tag_elasticache import elasticache_tag
from tag_route53 import route53_tag
from tag_acm import acm_tag
from tag_ecs import ecs_tag
from tag_ecr import ecr_tag
from tag_cloudwatch import cloudwatch_tag
from json import dumps
from boto3 import client
from os import environ


def notification(body, subject):
    sns = client('sns')
    response = sns.publish(
        TopicArn=environ['Email'],
        Message=body,
        Subject=subject
    )


def lambda_handler(event,context):
    try:
        if event["detail"].get("errorCode") and event["detail"]["errorCode"] != None:
            return {
                'statusCode': 201,
                'body': dumps("Error while creating service")
            }
        else:
            event_source = event["detail"]["eventSource"]
            if event_source == "ec2.amazonaws.com":
                response = ec2_tag(event)
            elif event_source == "acm.amazonaws.com":
                response = acm_tag(event)
            elif event_source == "elasticloadbalancing.amazonaws.com":
                response = elb_tag(event)
            elif event_source == "autoscaling.amazonaws.com":
                response = autoscaling_tag(event)
            elif event_source == "eks.amazonaws.com":
                response = eks_tag(event)
            elif event_source == "rds.amazonaws.com":
                response = rds_tag(event)
            elif event_source == "s3.amazonaws.com":
                response = s3_tag(event)
            elif event_source == "codepipeline.amazonaws.com":
                response = codepipeline_tag(event)
            elif event_source == "codebuild.amazonaws.com":
                response = codebuild_tag(event)
            elif event_source == "cloudtrail.amazonaws.com":
                response = cloudtrail_tag(event)
            elif event_source == "cloudfront.amazonaws.com":
                response = cloudfront_tag(event)
            elif event_source == "secretsmanager.amazonaws.com":
                response = secrets_tag(event)
            elif event_source == "kms.amazonaws.com":
                response = kms_tag(event)
            elif event_source == "lambda.amazonaws.com":
                response = lambda_function_tag(event)
            elif event_source == "apigateway.amazonaws.com":
                response = apigateway_tag(event)
            elif event_source == "sns.amazonaws.com":
                response = sns_tag(event)
            elif event_source == "elasticache.amazonaws.com":
                response = elasticache_tag(event)
            elif event_source == "route53.amazonaws.com":
                response = route53_tag(event)
            elif event_source == "ecs.amazonaws.com":
                response = ecs_tag(event)
            elif event_source == "ecr.amazonaws.com":
                response = ecr_tag(event)
            elif event_source == "logs.amazonaws.com":
                response = cloudwatch_tag(event)
            elif event_source == "guardduty.amazonaws.com":
                response = guardduty_tag(event)
            else:
                print("Event Source : ",event_source)
                print("Event Name : ",event["detail"]["eventName"])
                print("Invalid Event")
                return {
                    'statusCode': 422,
                    'body': dumps("Invalid Event")
                }
            if "Error" in response["body"]:
                notification(response["body"], "Error Adding Tag")
            return response
    except Exception as e:
        print("Error : ", e)
        return {
            'statusCode': 422,
            'body': dumps(f"Failed due to error {e}")
        }
