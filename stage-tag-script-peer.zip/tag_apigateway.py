from boto3 import client
from json import dumps

apigateway = client('apigateway')

map_tag = [{"Key": "map-migrated", "Value": "mig50286"}]


def add_tag(id):
    try:
        response = apigateway.tag_resource(
            resourceArn=id,
            tags={map_tag[0]["Key"]: map_tag[0]["Value"]}
        )
        return {
            'statusCode': 201,
            'body': dumps(f"Service Tagged")
        }
    except Exception as e:
        print("ERROR : ", e)
        return {
            'statusCode': 422,
            'body': dumps(f"Error Adding Tag: {e}")
        }


def check_tag(id):
    try:
        response = apigateway.get_tags(
            resourceArn=id
        )
        if response["tags"].get("map-migrated"):
            return {
                'statusCode': 201,
                'body': dumps("Tag Already Exists")
            }
        return {
            'statusCode': 201,
            'body': dumps("Tag Does Not Exists")
        }
    except Exception as e:
        print("ERROR : ", e)
        {
            'statusCode': 422,
            'body': dumps(f"Error Checking Tag: {e}")
        }


def apigateway_tag(event):
    try:
        if event["detail"]["eventName"] == "CreateRestApi":
            id = "arn:aws:apigateway:"+event["region"]+"::/restapis/" + \
                event["detail"]["responseElements"]["restapiUpdate"]["restApiId"]

        print("Service : ApiGateway")
        print("ID       : ", id)
        response = check_tag(id)
        if "Not" in response["body"]:
            return add_tag(id)
        else:
            return response
    except Exception as e:
        print("Error : ", e)
        return {
            'statusCode': 422,
            'body': dumps(f"Failed due to error {e}")
        }
