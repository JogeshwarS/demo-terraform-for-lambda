from boto3 import client
from json import dumps

autoscaling = client('autoscaling')

map_tag = [{"Key": "map-migrated", "Value": "mig50286"}]


def add_tag(id):
    try:
        response = autoscaling.create_or_update_tags(
            Tags=[
                {
                    'ResourceId': id,
                    'ResourceType': 'auto-scaling-group',
                    'Key': map_tag[0]["Key"],
                    'Value': map_tag[0]["Value"],
                    'PropagateAtLaunch': True
                }
            ]
        )
        return {
            'statusCode': 201,
            'body': dumps(f"Service Tagged")
        }
    except Exception as e:
        print("ERROR : ", e)
        return {
            'statusCode': 422,
            'body': dumps(f"Error Adding Tag: {e}")
        }


def check_tag(id):
    try:
        response = autoscaling.describe_tags(
            Filters=[
                {
                    'Name': 'auto-scaling-group',
                    'Values': [id]
                }
            ]
        )
        for tag in response["Tags"]:
            if tag["Key"] == "map-migrated":
                return {
                    'statusCode': 201,
                    'body': dumps("Tag Already Exists")
                }
        return {
            'statusCode': 201,
            'body': dumps("Tag Does Not Exists")
        }
    except Exception as e:
        print("ERROR : ", e)
        {
            'statusCode': 422,
            'body': dumps(f"Error Checking Tag: {e}")
        }


def autoscaling_tag(event):
    try:
        if event["detail"]["eventName"] == "CreateAutoScalingGroup":
            id = event["detail"]["requestParameters"]["autoScalingGroupName"]

        print("Service : AutoScaling")
        print("ID       : ", id)
        response = check_tag(id)
        if "Not" in response["body"]:
            return add_tag(id)
        else:
            return response
    except Exception as e:
        print("Error : ", e)
        return {
            'statusCode': 422,
            'body': dumps(f"Failed due to error {e}")
        }
