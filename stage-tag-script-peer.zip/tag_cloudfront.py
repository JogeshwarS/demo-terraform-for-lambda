from boto3 import client
from json import dumps

cloudfront = client('cloudfront')

map_tag = [{"Key": "map-migrated", "Value": "mig50286"}]


def add_tag(id):
    try:
        response = cloudfront.tag_resource(
            Resource=id,
            Tags={"Items": map_tag}
        )
        return {
            'statusCode': 201,
            'body': dumps(f"Service Tagged")
        }
    except Exception as e:
        print("ERROR : ", e)
        return {
            'statusCode': 422,
            'body': dumps(f"Error Adding Tag: {e}")
        }


def check_tag(id):
    try:
        response = cloudfront.list_tags_for_resource(
            Resource=id
        )
        for tag in response["Tags"]["Items"]:
            if tag["Key"] == "map-migrated":
                return {
                    'statusCode': 201,
                    'body': dumps("Tag Already Exists")
                }
        return {
            'statusCode': 201,
            'body': dumps("Tag Does Not Exists")
        }
    except Exception as e:
        print("ERROR : ", e)
        {
            'statusCode': 422,
            'body': dumps(f"Error Checking Tag: {e}")
        }


def cloudfront_tag(event):
    try:
        if event["detail"]["eventName"] == "CreateDistribution":
            id = event["detail"]["responseElements"]["distribution"]["aRN"]

        print("Service : Cloudfront")
        print("ID       : ", id)
        response = check_tag(id)
        if "Not" in response["body"]:
            return add_tag(id)
        else:
            return response
    except Exception as e:
        print("Error : ", e)
        return {
            'statusCode': 422,
            'body': dumps(f"Failed due to error {e}")
        }
