from boto3 import client
from json import dumps

codebuild = client('codebuild')

map_tag = [{"key": "map-migrated", "value": "mig50286"}]


def add_tag(id):
    try:
        response = codebuild.update_project(
            name=id,
            tags=map_tag
        )
        return {
            'statusCode': 201,
            'body': dumps(f"Service Tagged")
        }
    except Exception as e:
        print("ERROR : ", e)
        return {
            'statusCode': 422,
            'body': dumps(f"Error Adding Tag: {e}")
        }


def check_tag(id):
    try:
        response = codebuild.batch_get_projects(names=[id])["projects"][0]
        for tag in response["tags"]:
            if tag["key"] == "map-migrated":
                return {
                    'statusCode': 201,
                    'body': dumps("Tag Already Exists")
                }
            else:
                map_tag.append(tag)
        return {
            'statusCode': 201,
            'body': dumps("Tag Does Not Exists")
        }
    except Exception as e:
        print("ERROR : ", e)
        return {
            'statusCode': 422,
            'body': dumps(f"Error Checking Tag: {e}")
        }


def codebuild_tag(event):
    try:
        if event["detail"]["eventName"] == "CreateProject":
            id = event["detail"]["responseElements"]["project"]["name"]

        print("Service : CodeBuild")
        print("ID       : ", id)
        response = check_tag(id)
        if "Not" in response["body"]:
            return add_tag(id)
        else:
            return response
    except Exception as e:
        print("Error : ", e)
        return {
            'statusCode': 422,
            'body': dumps(f"Failed due to error {e}")
        }
