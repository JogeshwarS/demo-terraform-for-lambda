from boto3 import client
from json import dumps

ec2 = client('ec2')

map_tag = [{"Key": "map-migrated", "Value": "mig50286"}]


def add_tag(id):
    try:
        response = ec2.create_tags(
            Resources=[
                id,
            ],
            Tags=map_tag
        )
        return {
            'statusCode': 201,
            'body': dumps(f"Service Tagged")
        }
    except Exception as e:
        print("ERROR : ", e)
        return {
            'statusCode': 422,
            'body': dumps(f"Error Adding Tag: {e}")
        }


def check_tag(id):
    try:
        response = ec2.describe_tags(
            Filters=[
                {
                    "Name": "resource-id",
                    "Values": [
                        id,
                    ]
                },
            ]
        )
        for tag in response["Tags"]:
            if tag["Key"] == "map-migrated":
                return {
                    'statusCode': 201,
                    'body': dumps("Tag Already Exists")
                }
        return {
            'statusCode': 201,
            'body': dumps("Tag Does Not Exists")
        }
    except Exception as e:
        print("ERROR : ", e)
        {
            'statusCode': 422,
            'body': dumps(f"Error Checking Tag: {e}")
        }


def ec2_tag(event):
    try:
        if event["detail"]["eventName"] == "CreateKeyPair":
            id = event["detail"]["responseElements"]["keyPairId"]
        elif event["detail"]["eventName"] == "CreateSecurityGroup":
            id = event["detail"]["responseElements"]["groupId"]
        elif event["detail"]["eventName"] == "RunInstances":
            id = event["detail"]["responseElements"]["instancesSet"]["items"][0]["instanceId"]
        elif event["detail"]["eventName"] == "AllocateAddress":
            id = event["detail"]["responseElements"]["allocationId"]
        elif event["detail"]["eventName"] == "CreateVolume":
            id = event["detail"]["responseElements"]["volumeId"]
        elif event["detail"]["eventName"] == "CreateImage":
            id = event["detail"]["responseElements"]["imageId"]
        elif event["detail"]["eventName"] == "CreateSnapshot":
            id = event["detail"]["responseElements"]["snapshotId"]
        elif event["detail"]["eventName"] == "CreateNetworkInterface":
            id = event["detail"]["responseElements"]["networkInterface"]["networkInterfaceId"]
        elif event["detail"]["eventName"] == "CreateVpc":
            id = event["detail"]["responseElements"]["vpc"]["vpcId"]
        elif event["detail"]["eventName"] == "CreateSubnet":
            id = event["detail"]["responseElements"]["subnet"]["subnetId"]
        elif event["detail"]["eventName"] == "CreateInternetGateway":
            id = event["detail"]["responseElements"]["internetGateway"]["internetGatewayId"]
        elif event["detail"]["eventName"] == "CreateNatGateway":
            id = event["detail"]["responseElements"]["CreateNatGatewayResponse"]["natGateway"]["natGatewayId"]
        elif event["detail"]["eventName"] == "CreateRouteTable":
            id = event["detail"]["responseElements"]["routeTable"]["routeTableId"]
        elif event["detail"]["eventName"] == "CreateVpcPeeringConnection":
            id = event["detail"]["responseElements"]["vpcPeeringConnection"]["vpcPeeringConnectionId"]
        elif event["detail"]["eventName"] == "CreateLaunchTemplate":
            id = event["detail"]["responseElements"]["CreateLaunchTemplateResponse"]["launchTemplate"]["launchTemplateId"]
        else:
            return "Unknown Event"
        print("Service : EC2")
        print("ID       : ", id)
        response = check_tag(id)
        if "Not" in response["body"]:
            return add_tag(id)
        else:
            return response
    except Exception as e:
        print("Error : ", e)
        return {
            'statusCode': 422,
            'body': dumps(f"Failed due to error {e}")
        }