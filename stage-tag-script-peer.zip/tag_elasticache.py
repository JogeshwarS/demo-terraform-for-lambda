from boto3 import client
from json import dumps


map_tag = [{"Key": "map-migrated", "Value": "mig50286"}]


def add_tag(id, elasticache):
    try:
        response = elasticache.add_tags_to_resource(
            ResourceName=id,
            Tags=map_tag
        )
        return {
            'statusCode': 201,
            'body': dumps(f"Service Tagged")
        }
    except Exception as e:
        print("ERROR : ", e)
        return {
            'statusCode': 422,
            'body': dumps(f"Error Adding Tag: {e}")
        }


def check_tag(id, elasticache):
    try:
        response = elasticache.list_tags_for_resource(
            ResourceName=id
        )
        for tag in response["TagList"]:
            if tag["Key"] == "map-migrated":
                return {
                    'statusCode': 201,
                    'body': dumps("Tag Already Exists")
                }
        return {
            'statusCode': 201,
            'body': dumps("Tag Does Not Exists")
        }
    except Exception as e:
        print("ERROR : ", e)
        return {
            'statusCode': 422,
            'body': dumps(f"Error Checking Tag: {e}")
        }


def elasticache_tag(event):
    try:
        if event["detail"]["eventName"] == "CreateCacheCluster":
            id = event["detail"]["responseElements"]["aRN"]
        elif event["detail"]["eventName"] == "CreateReplicationGroup":
            id = event["detail"]["responseElements"]["aRN"]
        print("Service : ElastiCache")
        print("ID       : ", id)
        elasticache = client('elasticache', region_name=event["region"])
        response = check_tag(id, elasticache)
        if "Not" in response["body"]:
            return add_tag(id, elasticache)
        else:
            return response
    except Exception as e:
        print("Error : ", e)
        return {
            'statusCode': 422,
            'body': dumps(f"Failed due to error {e}")
        }