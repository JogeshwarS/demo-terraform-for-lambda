from boto3 import client
from json import dumps

elbv2 = client('elbv2')

map_tag = [{"Key": "map-migrated", "Value": "mig50286"}]


def add_tag(id):
    try:
        response = elbv2.add_tags(
            ResourceArns=[
                id,
            ],
            Tags=map_tag
        )
        return {
            'statusCode': 201,
            'body': dumps(f"Service Tagged")
        }
    except Exception as e:
        print("ERROR : ", e)
        return {
            'statusCode': 422,
            'body': dumps(f"Error Adding Tag: {e}")
        }


def check_tag(id):
    try:
        response = elbv2.describe_tags(
            ResourceArns=[
                id,
            ]
        )
        for tag in response["TagDescriptions"][0]["Tags"]:
            if tag["Key"] == "map-migrated":
                return {
                    'statusCode': 201,
                    'body': dumps("Tag Already Exists")
                }
        return {
            'statusCode': 201,
            'body': dumps("Tag Does Not Exists")
        }
    except Exception as e:
        print("ERROR : ", e)
        {
            'statusCode': 422,
            'body': dumps(f"Error Checking Tag: {e}")
        }


def elb_tag(event):
    try:
        if event["detail"]["eventName"] == "CreateTargetGroup":
            id = event["detail"]["responseElements"]["targetGroups"][0]["targetGroupArn"]
        elif event["detail"]["eventName"] == "CreateLoadBalancer":
            id = event["detail"]["responseElements"]["loadBalancers"][0]["loadBalancerArn"]

        print("Service : ELB")
        print("ID       : ", id)
        response = check_tag(id)
        if "Not" in response["body"]:
            return add_tag(id)
        else:
            return response
    except Exception as e:
        print("Error : ", e)
        return {
            'statusCode': 422,
            'body': dumps(f"Failed due to error {e}")
        }
