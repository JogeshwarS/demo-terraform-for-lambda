from boto3 import client
from json import dumps

lambda_function = client('lambda')

map_tag = [{"Key": "map-migrated", "Value": "mig50286"}]


def add_tag(id):
    try:
        response = lambda_function.tag_resource(
            Resource=id,
            Tags={map_tag[0]["Key"]: map_tag[0]["Value"]}
        )
        return {
            'statusCode': 201,
            'body': dumps(f"Service Tagged")
        }
    except Exception as e:
        print("ERROR : ", e)
        return {
            'statusCode': 422,
            'body': dumps(f"Error Adding Tag: {e}")
        }


def check_tag(id):
    try:
        response = lambda_function.list_tags(
            Resource=id
        )
        if response["Tags"].get("map-migrated"):
            return {
                'statusCode': 201,
                'body': dumps("Tag Already Exists")
            }
        return {
            'statusCode': 201,
            'body': dumps("Tag Does Not Exists")
        }
    except Exception as e:
        print("ERROR : ", e)
        {
            'statusCode': 422,
            'body': dumps(f"Error Checking Tag: {e}")
        }


def lambda_function_tag(event):
    try:
        if event["detail"]["eventName"] == "CreateFunction20150331":
            id = event["detail"]["responseElements"]["functionArn"]

        print("Service : Lambda")
        print("ID       : ", id)
        response = check_tag(id)
        if "Not" in response["body"]:
            return add_tag(id)
        else:
            return response
    except Exception as e:
        print("Error : ", e)
        return {
            'statusCode': 422,
            'body': dumps(f"Failed due to error {e}")
        }
