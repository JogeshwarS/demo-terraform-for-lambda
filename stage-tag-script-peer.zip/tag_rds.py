from boto3 import client
from json import dumps

rds = client('rds')
docdb = client('docdb')


map_tag = [{"Key": "map-migrated", "Value": "mig50286"}]


def add_tag(id):
    try:
        if "docdb" in id:
            response = docdb.add_tags_to_resource(
                ResourceName=id.replace("docdb", ""),
                Tags=map_tag
            )
        else:
            response = rds.add_tags_to_resource(
                ResourceName=id,
                Tags=map_tag
            )
        return {
            'statusCode': 201,
            'body': dumps(f"Service Tagged")
        }
    except Exception as e:
        print("ERROR : ", e)
        return {
            'statusCode': 422,
            'body': dumps(f"Error Adding Tag: {e}")
        }


def check_tag(id):
    try:
        if "docdb" in id:
            response = docdb.list_tags_for_resource(
                ResourceName=id.replace("docdb", "")
            )
        else:
            response = rds.list_tags_for_resource(
                ResourceName=id
            )
        for tag in response["TagList"]:
            if tag["Key"] == "map-migrated":
                return {
                    'statusCode': 201,
                    'body': dumps("Tag Already Exists")
                }
        return {
            'statusCode': 201,
            'body': dumps("Tag Does Not Exists")
        }
    except Exception as e:
        print("ERROR : ", e)
        {
            'statusCode': 422,
            'body': dumps(f"Error Checking Tag: {e}")
        }


def rds_tag(event):
    try:
        if event["detail"]["eventName"] == "CreateDBInstance":
            id = event["detail"]["responseElements"]["dBInstanceArn"]
        elif event["detail"]["eventName"] == "CreateDBInstanceReadReplica":
            id = event["detail"]["responseElements"]["dBInstanceArn"]
        elif event["detail"]["eventName"] == "CreateDBSnapshot":
            id = event["detail"]["responseElements"]["dBSnapshotArn"]
        elif event["detail"]["eventName"] == "CreateDBCluster":
            id = event["detail"]["responseElements"]["dBClusterArn"]+"-docdb"
        print("Service : RDS / DocDB")
        print("ID       : ", id)
        response = check_tag(id)
        if "Not" in response["body"]:
            return add_tag(id)
        else:
            return response
    except Exception as e:
        print("Error : ", e)
        return {
            'statusCode': 422,
            'body': dumps(f"Failed due to error {e}")
        }
