from boto3 import client
from json import dumps
from botocore.exceptions import ClientError


map_tag = [{"Key": "map-migrated", "Value": "mig50286"}]


def add_tag(id, s3):
    try:
        response = s3.put_bucket_tagging(
            Bucket=id,
            Tagging={
                'TagSet': map_tag
            }
        )
        print(response)
        return {
            'statusCode': 201,
            'body': dumps(f"Service Tagged")
        }
    except Exception as e:
        print("ERROR : ", e)
        return {
            'statusCode': 422,
            'body': dumps(f"Error Adding Tag: {e}")
        }


def check_tag(id, s3):
    try:
        response = s3.get_bucket_tagging(
            Bucket=id
        )
        for tag in response["TagSet"]:
            if tag["Key"] == "map-migrated":
                return {
                    'statusCode': 201,
                    'body': dumps("Tag Already Exists")
                }
            else:
                map_tag.append(tag)
        return {
            'statusCode': 201,
            'body': dumps("Tag Does Not Exists")
        }
    except ClientError as e:
        if e.response['Error']['Code'] == 'NoSuchTagSet':
            print("The TagSet does not exist.")
            return {
                'statusCode': 201,
                'body': dumps("Tag Does Not Exists")
            }
        else:
            print("ERROR : ", e)
            return {
                'statusCode': 422,
                'body': dumps(f"Error Checking Tag: {e}")
            }
    except Exception as e:
        print("ERROR : ", e)
        return {
            'statusCode': 422,
            'body': dumps(f"Error Checking Tag: {e}")
        }


def s3_tag(event):
    try:
        if event["detail"]["eventName"] == "CreateBucket":
            id = event["detail"]["requestParameters"]["bucketName"]
        print("Service : S3")
        print("ID       : ", id)
        s3 = client('s3', region_name=event["region"])
        response = check_tag(id, s3)
        if "Not" in response["body"]:
            return add_tag(id, s3)
        else:
            return response
    except Exception as e:
        print("Error : ", e)
        return {
            'statusCode': 422,
            'body': dumps(f"Failed due to error {e}")
        }