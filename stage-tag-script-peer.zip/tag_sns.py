from boto3 import client
from json import dumps

sns = client('sns')

map_tag = [{"Key": "map-migrated", "Value": "mig50286"}]


def add_tag(id):
    try:
        response = sns.tag_resource(
            ResourceArn=id,
            Tags=map_tag
        )
        return {
            'statusCode': 201,
            'body': dumps(f"Service Tagged")
        }
    except Exception as e:
        print("ERROR : ", e)
        return {
            'statusCode': 422,
            'body': dumps(f"Error Adding Tag: {e}")
        }


def check_tag(id):
    try:
        response = sns.list_tags_for_resource(
            ResourceArn=id
        )
        for tag in response["Tags"]:
            if tag["Key"] == "map-migrated":
                return {
                    'statusCode': 201,
                    'body': dumps("Tag Already Exists")
                }
        return {
            'statusCode': 201,
            'body': dumps("Tag Does Not Exists")
        }
    except Exception as e:
        print("ERROR : ", e)
        {
            'statusCode': 422,
            'body': dumps(f"Error Checking Tag: {e}")
        }


def sns_tag(event):
    try:
        if event["detail"]["eventName"] == "CreateTopic":
            id = event["detail"]["responseElements"]["topicArn"]

        print("Service : SNS")
        print("ID       : ", id)
        print("akshay")
        response = check_tag(id)
        if "Not" in response["body"]:
            return add_tag(id)
        else:
            return response
    except Exception as e:
        print("Error : ", e)
        return {
            'statusCode': 422,
            'body': dumps(f"Failed due to error {e}")
        }
